﻿#requires -Version 5.1
<#
.SYNOPSIS
  Disaster Recovery backup for vm-gw, vm-db and vm-app.
.DESCRIPTION
  Pulls configuration/inventory and Docker images over SSH, creates a logical
  PostgreSQL dump from the current Patroni leader, then stores an encrypted,
  deduplicated Restic snapshot on this Windows computer.
  Run manually, or register the daily task with -InstallDailyTask.
.NOTES
  Prerequisites on Windows: OpenSSH Client, restic, SSH key access, sufficient
  free disk space. Remote sudo commands must work non-interactively.
#>
[CmdletBinding()]
param(
    [string]$BackupRoot = "$env:USERPROFILE\DisasterRecovery",
    [string]$SshUser = "ubuntu",
    [string]$VmGw = "192.168.10.11",
    [string]$VmDb = "192.168.10.12",
    [string]$VmApp = "192.168.10.13",
    [string]$PatroniConfig = "/etc/patroni/patroni.yml",
    [string]$ResticRepository = "",
    [string]$ResticPasswordFile = "$env:USERPROFILE\.config\restic\dr-password.txt",
    [switch]$InstallDailyTask,
    [string]$TaskTime = "02:30",
    [switch]$SkipDockerImages,
    [switch]$SkipPostgreSql
)

$ErrorActionPreference = "Stop"
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$runDir = Join-Path $BackupRoot "staging\$timestamp"
$logDir = Join-Path $BackupRoot "logs"
New-Item -ItemType Directory -Force -Path $runDir, $logDir | Out-Null
$logFile = Join-Path $logDir "backup-$timestamp.log"
Start-Transcript -Path $logFile -Force | Out-Null

function Assert-Command([string]$Name) {
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        throw "Required command not found: $Name"
    }
}
function Invoke-Remote([string]$HostName, [string]$Command) {
    Write-Host "[$HostName] $Command"
    & ssh -o BatchMode=yes -o ConnectTimeout=15 "$SshUser@$HostName" $Command
    if ($LASTEXITCODE -ne 0) { throw "SSH command failed on $HostName (exit $LASTEXITCODE)" }
}
function Copy-Remote([string]$HostName, [string]$RemotePath, [string]$LocalPath) {
    & scp -o BatchMode=yes -o ConnectTimeout=15 "$SshUser@$HostName`:$RemotePath" $LocalPath
    if ($LASTEXITCODE -ne 0) { throw "SCP failed: $HostName:$RemotePath" }
}
function Quote-Bash([string]$Value) {
    return "'" + $Value.Replace("'", "'\''") + "'"
}

try {
    Assert-Command ssh
    Assert-Command scp
    Assert-Command restic

    if (-not $ResticRepository) {
        $ResticRepository = Join-Path $BackupRoot "restic-repository"
    }
    if (-not (Test-Path $ResticPasswordFile)) {
        throw "Restic password file missing: $ResticPasswordFile. Create it securely before the first run."
    }
    $env:RESTIC_REPOSITORY = $ResticRepository
    $env:RESTIC_PASSWORD_FILE = $ResticPasswordFile

    $nodes = @(
        @{ Name = "vm-gw"; Host = $VmGw },
        @{ Name = "vm-db"; Host = $VmDb },
        @{ Name = "vm-app"; Host = $VmApp }
    )

    # Remote inventory/config bundle. No live database or volume files are tarred here.
    foreach ($node in $nodes) {
        $name = $node.Name
        $hostName = $node.Host
        $remoteDir = "/tmp/dr-$timestamp-$name"
        $remoteTar = "/tmp/dr-$timestamp-$name.tar.gz"
        $cmd = @"
set -e
D=$remoteDir
sudo mkdir -p "`$D"
sudo chmod 700 "`$D"
sudo bash -c '
set -e
D="$remoteDir"
OUT="$D/inventory.txt"
{
  echo "NODE=$name"
  date -Is
  hostnamectl
  uname -a
  lsblk -f
  df -hT
  ip -br address
  ip route
  systemctl list-unit-files --state=enabled
  docker version 2>/dev/null || true
  docker ps -a --no-trunc 2>/dev/null || true
  docker image ls --digests 2>/dev/null || true
  docker network ls 2>/dev/null || true
  docker service ls 2>/dev/null || true
} > "$OUT" 2>&1
'
sudo tar -czf $remoteTar -C / --ignore-failed-read \
  etc/hostname etc/hosts etc/fstab etc/netplan etc/systemd/system \
  etc/nginx etc/keepalived etc/haproxy etc/patroni \
  etc/ssh/sshd_config etc/ssh/sshd_config.d \
  opt/redis opt/kafka opt/seaweedfs \
  usr/local/bin/weed \
  2>/dev/null || true
sudo tar -rf /tmp/dr-$timestamp-$name.tar -C /tmp "dr-$timestamp-$name" 2>/dev/null || true
sudo chown `$USER:`"`$USER" $remoteTar 2>/dev/null || true
"@
        # Build bundle in a simpler, predictable remote shell invocation.
        $remoteScript = @"
set -e
D='$remoteDir'
T='$remoteTar'
sudo rm -rf "`$D" "`$T"
sudo mkdir -p "`$D"
sudo chmod 700 "`$D"
sudo bash -c '{
  echo "NODE=$name"; date -Is; hostnamectl; uname -a
  echo "=== DISKS ==="; lsblk -f; df -hT
  echo "=== NETWORK ==="; ip -br address; ip route
  echo "=== ENABLED SERVICES ==="; systemctl list-unit-files --state=enabled
  echo "=== DOCKER ==="; docker version 2>/dev/null || true
  docker ps -a --no-trunc 2>/dev/null || true
  docker image ls --digests 2>/dev/null || true
  docker network ls 2>/dev/null || true
  docker service ls 2>/dev/null || true
}' > "`$D/inventory.txt" 2>&1
sudo tar -czf "`$T" -C / --ignore-failed-read \
  etc/hostname etc/hosts etc/fstab etc/netplan \
  etc/systemd/system etc/nginx etc/keepalived etc/haproxy etc/patroni \
  etc/ssh/sshd_config etc/ssh/sshd_config.d \
  opt/redis opt/kafka opt/seaweedfs \
  usr/local/bin/weed 2>/dev/null
sudo chown "`$(id -u):`$(id -g)" "`$T"
"@
        Invoke-Remote $hostName ("bash -lc " + (Quote-Bash $remoteScript))
        $localTar = Join-Path $runDir "$name-config.tar.gz"
        Copy-Remote $hostName $remoteTar $localTar
        Invoke-Remote $hostName "sudo rm -rf $remoteDir $remoteTar"
    }

    # Export all locally cached Docker images from db/app. Images are artifacts, not running-container snapshots.
    if (-not $SkipDockerImages) {
        foreach ($node in @(@{Name="vm-db";Host=$VmDb}, @{Name="vm-app";Host=$VmApp})) {
            $remote = "/tmp/dr-$timestamp-$($node.Name)-images.tar"
            $remoteCmd = "set -e; IDS=`$(sudo docker images -q | sort -u); if [ -n `"`$IDS`" ]; then sudo docker save -o $remote `$IDS; sudo chown `$(id -u):`$(id -g) $remote; else echo 'No Docker images found' >&2; exit 2; fi"
            Invoke-Remote $node.Host ("bash -lc " + (Quote-Bash $remoteCmd))
            Copy-Remote $node.Host $remote (Join-Path $runDir "$($node.Name)-docker-images.tar")
            Invoke-Remote $node.Host "sudo rm -f $remote"
        }
    }

    # Identify the Patroni leader from patronictl JSON, then run pg_dumpall there.
    if (-not $SkipPostgreSql) {
        $leaderCmd = "sudo patronictl -c $PatroniConfig list -f json"
        $leaderJson = & ssh -o BatchMode=yes -o ConnectTimeout=15 "$SshUser@$VmDb" $leaderCmd
        if ($LASTEXITCODE -ne 0) { throw "Cannot query Patroni leader using patronictl on $VmDb" }
        $leaderRows = $leaderJson | ConvertFrom-Json
        $leader = $leaderRows | Where-Object {
            ($_.Role -eq "Leader") -or ($_.role -eq "Leader") -or ($_.Role -eq "Primary") -or ($_.role -eq "Primary")
        } | Select-Object -First 1
        if (-not $leader) { throw "Patroni leader not found in patronictl JSON. No PostgreSQL dump was taken." }
        $leaderHost = [string]$leader.Host
        if (-not $leaderHost) { $leaderHost = [string]$leader.host }
        if (-not $leaderHost) { throw "Leader IP not found in patronictl output." }

        $remoteDump = "/tmp/dr-$timestamp-postgresql.sql.gz"
        $dumpCmd = "set -e; sudo -n -u postgres pg_dumpall | gzip -1 > $remoteDump; sudo chown `$(id -u):`$(id -g) $remoteDump"
        Invoke-Remote $leaderHost ("bash -lc " + (Quote-Bash $dumpCmd))
        Copy-Remote $leaderHost $remoteDump (Join-Path $runDir "postgresql-all.sql.gz")
        Invoke-Remote $leaderHost "sudo rm -f $remoteDump"
        $leaderInfo = "Patroni leader at backup time: $leaderHost`r`n"
        Set-Content -Path (Join-Path $runDir "postgresql-leader.txt") -Value $leaderInfo -Encoding UTF8
    }

    # Persist run metadata and take an encrypted Restic snapshot.
    @"
Backup timestamp: $timestamp
Nodes: $VmGw, $VmDb, $VmApp
PostgreSQL: $(if ($SkipPostgreSql) {"SKIPPED"} else {"pg_dumpall logical dump"})
Docker image export: $(if ($SkipDockerImages) {"SKIPPED"} else {"vm-db and vm-app local images"})
SeaweedFS volume data: NOT INCLUDED (see README: offline volume backup procedure)
Filer metadata: included in PostgreSQL dump only if it resides in that PostgreSQL cluster.
"@ | Set-Content -Path (Join-Path $runDir "BACKUP-MANIFEST.txt") -Encoding UTF8

    & restic init 2>$null
    & restic backup $runDir --tag "cluster-dr" --tag $timestamp
    if ($LASTEXITCODE -ne 0) { throw "Restic backup failed (exit $LASTEXITCODE)" }
    & restic forget --tag "cluster-dr" --keep-daily 14 --keep-weekly 8 --keep-monthly 12 --prune
    if ($LASTEXITCODE -ne 0) { Write-Warning "Restic retention/prune failed; snapshot may still be valid." }

    Write-Host "BACKUP COMPLETED" -ForegroundColor Green
    Write-Host "Restic repository: $ResticRepository"
    # Remove plaintext staging (configs and SQL dump) after successful encrypted snapshot.
    Remove-Item -LiteralPath $runDir -Recurse -Force
}
catch {
    Write-Error $_
    exit 1
}
finally {
    Stop-Transcript | Out-Null
}

if ($InstallDailyTask) {
    $scriptPath = $MyInvocation.MyCommand.Path
    if (-not $scriptPath) { throw "Save this script as backup.ps1 before installing the scheduled task." }
    $taskArgs = "-NoProfile -ExecutionPolicy Bypass -File `"$scriptPath`" -BackupRoot `"$BackupRoot`" -SshUser `"$SshUser`" -VmGw `"$VmGw`" -VmDb `"$VmDb`" -VmApp `"$VmApp`" -PatroniConfig `"$PatroniConfig`" -ResticRepository `"$ResticRepository`" -ResticPasswordFile `"$ResticPasswordFile`""
    if ($SkipDockerImages) { $taskArgs += " -SkipDockerImages" }
    if ($SkipPostgreSql) { $taskArgs += " -SkipPostgreSql" }
    $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument $taskArgs
    $trigger = New-ScheduledTaskTrigger -Daily -At $TaskTime
    $principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Highest
    Register-ScheduledTask -TaskName "Cluster-Disaster-Recovery-Backup" -Action $action -Trigger $trigger -Principal $principal -Description "Daily encrypted DR backup for vm-gw, vm-db and vm-app" -Force | Out-Null
    Write-Host "Daily task installed at $TaskTime. It runs when this Windows user is logged on."
}
