#!/usr/bin/env bash
# Disaster Recovery restore runbook for vm-gw, vm-db and vm-app.
# This is deliberately a guided runbook: it does NOT overwrite network,
# PostgreSQL, SeaweedFS, Docker or Swarm state automatically.
set -Eeuo pipefail

BACKUP_DIR="${1:-}"
TARGET_ROLE="${2:-all}"   # all | gw | db | app
RESTORE_MODE="${3:-inspect}" # inspect | apply-configs | restore-postgres

if [[ -z "$BACKUP_DIR" || ! -d "$BACKUP_DIR" ]]; then
  echo "Usage: $0 <restored-backup-directory> [all|gw|db|app] [inspect|apply-configs|restore-postgres]"
  exit 2
fi

echo "Backup directory: $BACKUP_DIR"
echo "Target: $TARGET_ROLE"
echo "Mode: $RESTORE_MODE"

case "$RESTORE_MODE" in
  inspect)
    echo "=== Backup manifest ==="
    cat "$BACKUP_DIR/BACKUP-MANIFEST.txt" 2>/dev/null || true
    echo "=== Contents ==="
    find "$BACKUP_DIR" -maxdepth 2 -type f -printf '%P (%s bytes)\n' | sort
    echo
    echo "No changes made. Review the manifest and inventory before proceeding."
    ;;
  apply-configs)
    echo "WARNING: config restore can break SSH/network access. Restore only on a fresh host"
    echo "after confirming its role/IP and reviewing extracted files."
    read -r -p "Type APPLY-CONFIGS to continue: " answer
    [[ "$answer" == "APPLY-CONFIGS" ]] || { echo "Cancelled."; exit 1; }

    roles=()
    case "$TARGET_ROLE" in
      all) roles=(vm-gw vm-db vm-app) ;;
      gw) roles=(vm-gw) ;;
      db) roles=(vm-db) ;;
      app) roles=(vm-app) ;;
      *) echo "Unknown target role: $TARGET_ROLE"; exit 2 ;;
    esac

    for role in "${roles[@]}"; do
      archive="$BACKUP_DIR/${role}-config.tar.gz"
      [[ -f "$archive" ]] || { echo "Missing $archive"; exit 1; }
      tmp="$(mktemp -d)"
      tar -xzf "$archive" -C "$tmp"
      echo "Extracted $role config into $tmp"
      echo "Review first. To copy selected files manually:"
      echo "  sudo rsync -aHAX --numeric-ids '$tmp/etc/' /etc/"
      echo "Do NOT blindly overwrite /etc/netplan, /etc/ssh, /etc/fstab or host identity."
      echo "After reviewing, copy only the required service config files."
    done
    ;;
  restore-postgres)
    dump="$BACKUP_DIR/postgresql-all.sql.gz"
    [[ -f "$dump" ]] || { echo "Missing PostgreSQL dump: $dump"; exit 1; }
    echo "This restores a logical dump into an already initialized PostgreSQL cluster."
    echo "Do not run on a production cluster with existing data."
    read -r -p "Type RESTORE-POSTGRES to continue: " answer
    [[ "$answer" == "RESTORE-POSTGRES" ]] || { echo "Cancelled."; exit 1; }
    echo "Restore command (run as postgres on the intended new primary):"
    echo "  gunzip -c '$dump' | sudo -u postgres psql -X -v ON_ERROR_STOP=1 -d postgres"
    echo "Note: pg_dumpall includes roles and databases. Ensure the target is empty/new."
    ;;
  *)
    echo "Unknown mode: $RESTORE_MODE"
    exit 2
    ;;
esac

cat <<'EOF'

IMPORTANT RECOVERY ORDER
1. Install Ubuntu on all three VMs; set hostnames, static IPs, DNS, time sync and disks/LVM.
2. Restore reviewed network/firewall/SSH settings and service configuration.
3. Install exact Docker/SeaweedFS/PostgreSQL/Patroni/Redis/Kafka versions.
4. Restore PostgreSQL only to a new, empty cluster; rebuild Patroni membership deliberately.
5. Restore SeaweedFS master metadata and volume data using the documented offline procedure.
   Do not treat SeaweedFS replication as a backup; this bundle does not contain volume files.
6. Recreate a NEW Docker Swarm from declarative stack/service files and re-create secrets
   from the separately stored encrypted secret escrow. Do not copy /var/lib/docker/swarm
   onto newly installed nodes.
7. Start Filers, verify Postgres filer metadata, start application and validate uploads/downloads.
8. Test failover and compare SHA256 checksums before declaring recovery complete.
EOF
