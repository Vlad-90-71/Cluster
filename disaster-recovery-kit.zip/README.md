# Disaster Recovery для vm-gw / vm-db / vm-app

## 1. Целевая схема

**Windows-компьютер — отдельная точка хранения**, не часть кластера. На нём хранится Restic-репозиторий (шифрованный, дедуплицированный) и временные staging-архивы.

- `backup.ps1` запускается вручную или ежедневно через Windows Task Scheduler.
- SSH используется только для чтения/сбора с Linux-узлов; предпочтительна отдельная SSH-учётная запись с ключом.
- Restic шифрует резервный набор на Windows до записи в репозиторий.
- Восстановление выполняется на чистых Ubuntu VM по шагам, а не автоматическим копированием всего `/etc` и `/var/lib`.

## 2. Что включено в текущий backup.ps1

| Состав | Источник | Метод |
|---|---|---|
| Конфигурации узлов | Все 3 VM | Архив выбранных каталогов `/etc`, `/opt`, systemd и бинарника `weed` |
| Инвентаризация | Все 3 VM | hostname, ОС, диски, сеть, включённые службы, Docker |
| Docker images | vm-db и vm-app | `docker save` всех локально имеющихся образов |
| PostgreSQL | Текущий Patroni Leader | Логический `pg_dumpall` |
| Restic snapshot | Windows | Шифрование, дедупликация, retention 14 daily / 8 weekly / 12 monthly |

PostgreSQL dump включает базы и роли. Он должен содержать и `seaweedfs_filer`, если эта БД размещена в том же PostgreSQL-кластере.

## 3. Что нельзя считать закрытым автоматически

**SeaweedFS volume data.** Текущий скрипт намеренно не копирует `/srv/seaweedfs/data` и `/var/lib/seaweedfs/volume` «на горячую»: обычный `tar` активных `.dat/.idx` файлов не является гарантированно согласованным backup. Репликация `001` — отказоустойчивость, а не резервная копия.

Перед вводом DR в эксплуатацию добавьте отдельную процедуру offline backup томов:
1. Проверить, что все volume replicas здоровы и `volume.list` показывает нужные копии.
2. По одному узлу за раз вывести его volume server из обслуживания. На `vm-gw` остановить только `seaweedfs-volume.service`, не master.
3. На `vm-db` и `vm-app` сначала точно определить, как запущен контейнер `seaweedfs` (команда `weed server` может включать несколько ролей). Не останавливать контейнер вслепую, если он содержит также master/другие роли. Временное выключение должно оставлять рабочие копии на двух других узлах.
4. Скопировать offline volume directory (`/srv/seaweedfs/data` для db/app, `/var/lib/seaweedfs/volume` для gw) в отдельный staging на Windows; затем вернуть сервис и дождаться восстановления топологии.
5. Повторить для следующего узла только после проверки первого. Не останавливать два volume server одновременно.
6. Сохранить также master metadata (`/var/lib/seaweedfs/master` на gw) и конфиги всех master peers.

Эта процедура требует отдельной проверки реальных systemd/Docker команд и свободного места. Не включена в скрипт автоматически, чтобы не остановить production SeaweedFS неверной командой.

## 4. Первый запуск на Windows

1. Установить OpenSSH Client (Windows Optional Features) и `restic`.
2. Настроить SSH-ключ и проверить вход без пароля:
   `ssh ubuntu@192.168.10.11 hostname`
   `ssh ubuntu@192.168.10.12 hostname`
   `ssh ubuntu@192.168.10.13 hostname`
3. Проверить на узлах `sudo -n` для команд, используемых backup. Если sudo требует пароль, настройте ограниченный sudoers для backup-команд либо запускайте remote-команды через отдельный безопасный механизм. Не храните пароль в скрипте.
4. Создать файл пароля Restic, например:
   `%USERPROFILE%\.config\restic\dr-password.txt`
   Случайная длинная парольная фраза; ACL только для текущего Windows-пользователя. Сохранить её отдельно в менеджере паролей: без неё backup не расшифровать.
5. Запустить PowerShell:
   `.\backup.ps1`
6. Проверить:
   `restic snapshots`
   `restic check`

Пример:
`.\backup.ps1 -BackupRoot 'D:\DR-Backups'`

## 5. Ежедневный и ручной запуск

Ежедневная задача в 02:30:
`.\backup.ps1 -InstallDailyTask -TaskTime '02:30' -BackupRoot 'D:\DR-Backups'`

Ручной запуск:
`.\backup.ps1 -BackupRoot 'D:\DR-Backups'`

Задача зарегистрирована для текущего Windows-пользователя и по умолчанию выполняется, когда он вошёл в систему. Для работы при выключенном/спящем ПК включите пробуждение в Task Scheduler/питании; резервное копирование не произойдёт, если компьютер недоступен.

## 6. Проверка восстановления

Сначала восстановить Restic snapshot в отдельную папку:
`restic snapshots`
`restic restore latest --target C:\DR-Restore-Test`

Затем на Linux:
`chmod +x restore.sh`
`./restore.sh /path/to/restored-snapshot inspect`

Режимы `apply-configs` и `restore-postgres` требуют явного подтверждения и не должны выполняться на действующем кластере.

## 7. Обязательные дополнительные элементы DR

Хранить отдельно и в зашифрованном виде:
- исходные значения Docker Swarm secrets/configs (секреты нельзя прочитать обратно из работающего Swarm);
- SSH private keys / recovery access, сертификаты TLS и ключи шифрования;
- Docker Compose/stack-файлы, Dockerfile, deploy.ps1, точные image tags/digests;
- версии Ubuntu, Docker Engine, PostgreSQL, Patroni, SeaweedFS, Redis, Kafka;
- схема IP/VIP, Keepalived priority, Nginx upstreams, firewall rules, DNS;
- инструкции и ключи доступа к Windows backup disk.

Не сохранять пароли открытым текстом рядом с backup. Сам Windows-компьютер не должен быть единственной копией: периодически копировать Restic repository на отключаемый внешний диск или другой независимый носитель.

## 8. Ограничения текущего набора

Это безопасная базовая версия: она собирает конфигурации, образы и PostgreSQL logical dump. Она **не** делает PITR PostgreSQL/WAL archive, не резервирует физические SeaweedFS volume files, не сохраняет Kafka message log, Redis RDB/AOF и не экспортирует текущие Swarm secrets. До закрытия этих пунктов комплект не обеспечивает полное восстановление всех данных с нуля.
